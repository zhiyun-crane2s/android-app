package me.rajtech.crane2s.ui.stream

import android.os.Bundle
import android.view.TextureView
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.serenegiant.usb.USBMonitor
import com.serenegiant.usb.UVCCamera
import com.serenegiant.usb.widget.UVCCameraTextureView
import com.serenegiant.uvccamera.UVCCameraHelper
import me.rajtech.crane2s.R
import java.net.Inet4Address
import java.net.NetworkInterface

class StreamActivity : AppCompatActivity() {

    private lateinit var uvcView: UVCCameraTextureView
    private lateinit var btnStart: Button
    private lateinit var tvUrl: TextView
    private lateinit var tvStatus: TextView
    private lateinit var cameraHelper: UVCCameraHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stream)

        // Bind views
        uvcView = findViewById(R.id.uvc_view)
        btnStart = findViewById(R.id.btn_start)
        tvUrl = findViewById(R.id.tv_url)
        tvStatus = findViewById(R.id.tv_status)

        // Display local IP
        tvUrl.text = "http://${getLocalIp()}:8080"

        // Initialize camera helper
        cameraHelper = UVCCameraHelper.getInstance().apply {
            initUSBMonitor(this@StreamActivity, uvcView, null)
            setDefaultPreviewSize(1280, 720)
            setDefaultFrameFormat(UVCCameraHelper.FRAME_FORMAT_YUYV)
            setOnPreviewFrameListener { frameBytes ->
                // TODO: send frameBytes to encoder or WebRTC
            }
        }

        btnStart.setOnClickListener {
            if (!cameraHelper.isCameraOpened) {
                cameraHelper.startPreview(uvcView.surfaceTexture)
                tvStatus.text = "Status: Previewing"
            } else {
                tvStatus.text = "Camera already started"
            }
        }
    }

    override fun onStart() {
        super.onStart()
        cameraHelper.registerUSB()
    }

    override fun onStop() {
        cameraHelper.unregisterUSB()
        super.onStop()
    }

    override fun onDestroy() {
        cameraHelper.release()
        super.onDestroy()
    }

    private fun getLocalIp(): String {
        return NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress ?: "0.0.0.0"
    }
}
